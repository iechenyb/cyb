package com.zxn.example.service.compute;

public interface Compute 
{
	public String computeNums(int x, int y);
}
